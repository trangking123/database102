// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
const firebaseApp = initializeApp({
  apiKey: "AIzaSyDeniiaARZVtUyISSrvdcCqgFhN56THZ-4",
  authDomain: "mmdatabse.firebaseapp.com",
  projectId: "mmdatabse",
  storageBucket: "mmdatabse.appspot.com",
  messagingSenderId: "995545420676",
  appId: "1:995545420676:web:251faeb1c86932b1d903d1",
  measurementId: "G-GSHPM3C58B",
});

const db = getFirestore(firebaseApp);
export default db;
