<template>
  <form class="row g-3">
    <label for="exampleFormControlInput1" class="form-label">กรอกข้อมูล</label>
    <div class="col-md-4">
      <label for="validationTooltip01" class="form-label">ชื่อ</label>
      <input
        type="text"
        class="form-control"
        id="validationTooltip01"
        required
        v-model="nameC"
      />
      <div class="valid-tooltip">Looks good!</div>
    </div>
    <div class="col-md-4">
      <label for="validationTooltip02" class="form-label">นามสกุล</label>
      <input
        type="text"
        class="form-control"
        id="validationTooltip02"
        v-model="lastnameC"
        required
      />
      <div class="valid-tooltip">Looks good!</div>
    </div>
    <div class="col-md-4">
      <label for="validationTooltip02" class="form-label">E-mail</label>
      <input
        type="text-email"
        class="form-control"
        id="validationTooltip02"
        v-model="mails"
        required
      />
      <div class="valid-tooltip">Looks good!</div>
    </div>
    <div class="mb-3">
      <span>ผลตรวจATK</span>
      <input
        class="form-check-input"
        type="radio"
        name="flexRadioDefault"
        id="flexRadioDefault1"
        v-model="checkedNames"
        value="+"
      />
      <label class="form-check-label" for="flexRadioDefault1"> + </label>

      <input
        class="form-check-input"
        type="radio"
        name="flexRadioDefault"
        id="flexRadioDefault2"
        v-model="checkedNames"
        value="-"
      />
      <label class="form-check-label" for="flexRadioDefault2"> - </label>
      <p>หมายโทรศัพท์<input v-model="numberphone" /></p>

      <button @click="addData()" type="button" class="btn btn-outline-dark">
        เสร็จสิ้น
      </button>
      <button @click="readData()" type="button" class="btn btn-outline-light">
        ดูข้อมูล
      </button>
      <h4>{{ dbData }}</h4>
      <table class="table table-success table-striped">
        <thead>
          <tr>
            <th scope="col">ลำดับ</th>
            <th scope="col">ชื่อ</th>
            <th scope="col">นามสกุล</th>
            <th scope="col">ATK</th>
            <th scope="col">E-mail</th>
            <th scope="col">เบอร์โทรศัพท์</th>
          </tr>
        </thead>
        <tbody v-for="(item, index) in table" :key="index">
          <tr>
            <th scope="row">{{ index }}</th>
            <td>{{ item.data.name }}</td>
            <td>{{ item.data.lastname }}</td>
            <td>{{ item.data.atk }}</td>
            <td>{{ item.data.mail }}</td>
            <td>{{ item.data.number }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </form>
</template>
<script>
import db from "../plugins/firebaseInit";
import { collection, addDoc, getDocs } from "firebase/firestore";

export default {
  data() {
    return {
      dbData: "",
      nameC: " ",
      lastnameC: "",
      checkedNames: "",
      mails: "",
      numberphone: "",
      table: [],
    };
  },
  methods: {
    async addData() {
      try {
        const docRef = await addDoc(collection(db, "Covid"), {
          name: this.nameC,
          lastname: this.lastnameC,
          atk: this.checkedNames,
          mail: this.mails,
          number: this.numberphone,
        });
        console.log("Document written with ID: ", docRef.id);
      } catch (e) {
        console.error("Error adding document: ", e);
      }
    },
    async readData() {
      const querySnapshot = await getDocs(collection(db, "Covid"));
      querySnapshot.forEach((doc) => {
        console.log(`${doc.id} => ${doc.data()}`);
        this.table.push({ id: doc.id, data: doc.data() });
      });
    },
    /* addit() {
      this.additems.push({
        text: this.nameC,
      });
    },*/
  },
};
</script>
<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
.trang {
  position: left;
}
</style>
